$(document).ready(inicio)
$(document).keydown(manejar_evento)

function inicio(){
	lienzo = $("#lienzo")[0];
	contexto = lienzo.getContext("2d");
	buffer = document.createElement("canvas");
	kong = new kong();
	barril1 = new barril1();
	barril2 = new barril2();
	barril3 = new barril3();
	barril4 = new barril4();
	barril5 = new barril5();

	animar();	
}

function animar(){
	buffer.width = lienzo.width;
	buffer.height = lienzo.height;
	contextoBuffer = buffer.getContext("2d");
	
	contextoBuffer.clearRect(0,0, buffer.width, buffer.height);
	kong.dibujar(contextoBuffer);

	barril1.dibujar(contextoBuffer);
	barril2.dibujar(contextoBuffer);
	barril3.dibujar(contextoBuffer);
	barril4.dibujar(contextoBuffer);
	barril5.dibujar(contextoBuffer);
	barril1.actualizar();
	barril2.actualizar();
	barril3.actualizar();
	barril4.actualizar();
	barril5.actualizar();
	
	contexto.clearRect(0,0, lienzo.width, lienzo.height);
	contexto.drawImage(buffer, 0, 0);
	
	setTimeout("animar()",20);
}

function manejar_evento(event){
	//alert(event.which);
	if (event.which == 39){
		kong.moverse("derecha");
	}
	if(event.which == 37){
		kong.moverse("izquierda");
	}
}

function kong(){
	this.x = 600;
	this.y = 570;
	this.vel = 1;
	this.img = $("#kong")[0];
	
	this.dibujar = function(ctx){
		ctx.drawImage(this.img, this.x, this.y);
	}

	this.moverse = function(accion){
		if (accion == "derecha") {
			this.x = this.x+15;
		}
			if(accion == "izquierda"){
			this.x = this.x -15;
		}
		if(this.x==-15|| this.x==-38){
		   this.x = lienzo.width-128;}else{
		   
		if(this.x == lienzo.width-113 || this.x == lienzo.width-90){
		this.x = 0;}
	}}
		
}

function barril1(){
	this.x = 0;
	this.y = 0;
	this.vel = 3.2;
	this.img = $("#barril")[0];

	this.dibujar = function(ctx){
		ctx.drawImage(this.img, this.x, this.y);
	}
this.actualizar = function (){
		this.y += this.vel;
		if (this.y +170 >= lienzo.height) {this.y = -150;} 
	}	
}

function barril2(){
	this.x = 350;
	this.y = 0;
	this.vel = 2.5;
	this.img = $("#barril")[0];

	this.dibujar = function(ctx){
		ctx.drawImage(this.img, this.x, this.y);
	}
this.actualizar = function (){
		this.y += this.vel;
		if (this.y +170 >= lienzo.height) {this.y = -150;}
	}	
}

function barril3(){
	this.x = 700;
	this.y = 0;
	this.vel = 1.2;
	this.img = $("#barril")[0];

	this.dibujar = function(ctx){
		ctx.drawImage(this.img, this.x, this.y);
	}
this.actualizar = function (){
		this.y += this.vel;
		if (this.y +170 >= lienzo.height) {this.y = -150;}
	}	
}

function barril4(){
	this.x = 1000;
	this.y = 0;
	this.vel = 4;
	this.img = $("#barril")[0];

	this.dibujar = function(ctx){
		ctx.drawImage(this.img, this.x, this.y);
	}
this.actualizar = function (){
		this.y += this.vel;
		if (this.y +170 >= lienzo.height) {this.y = -150;}
	}	
}

function barril5(){
	this.x = 1300;
	this.y = 0;
	this.vel = 3;
	this.img = $("#barril")[0];

	this.dibujar = function(ctx){
		ctx.drawImage(this.img, this.x, this.y);
	}
this.actualizar = function (){
		this.y += this.vel;
		if (this.y +170 >= lienzo.height) {this.y = -150;}
	}	
}
/*
	this.cambiar_velocidad = function (accion){
		if(accion == "aumentar"){
			this.vel += 1;
		}else{
			this.vel -= 1;
		}
	}
*/